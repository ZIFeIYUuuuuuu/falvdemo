/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Clause {
  id: string;
  section: string;
  title: string;
  content: string;
  scenarios: string[];
}

export interface Policy {
  id: string;
  name: string;
  code: string;
  company: string;
  status: 'active' | 'inactive' | 'pending';
  type: string;
  waitingPeriod: string;
  gracePeriod: string;
  freeLookPeriod: string;
  clauses: Clause[];
}

export interface Citation {
  policyId: string;
  policyName: string;
  clauseId: string;
  clauseTitle: string;
  section: string;
  matchedText: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  citations?: Citation[];
  verdict?: 'valid' | 'invalid' | 'conditional' | 'neutral'; // 研判结论
  verdictText?: string; // 结论摘要
}

export interface RAGResult {
  policy: Policy;
  clause: Clause;
  score: number;
}

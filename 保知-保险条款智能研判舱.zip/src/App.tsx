/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Trash2, 
  ShieldAlert
} from 'lucide-react';

import { POLICIES } from './data/policies';
import { Message, Citation } from './types';

// Component imports
import Header from './components/Header';
import PolicyVault from './components/PolicyVault';
import TemplateDeck from './components/TemplateDeck';
import VerdictDisplay from './components/VerdictDisplay';
import ContractInspector from './components/ContractInspector';

export default function App() {
  const [selectedPolicyId, setSelectedPolicyId] = useState<string | null>(null);
  const [activeInput, setActiveInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [inspectingCitation, setInspectingCitation] = useState<Citation | null>(null);

  // Start with a beautiful pre-loaded Audit Report to immediately demonstrate citations & inspector UX
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-memo',
      sender: 'assistant',
      verdict: 'neutral',
      verdictText: '智能合同条款分析系统挂载就绪。请直接输入您的保单疑问，或选择下方的判定场景。',
      content: `## 独立合同审计首审就位

欢迎体验 **保知（BaoZhi） · 保险条款智能研判舱**。我们彻底抛弃了传统“AI味”浓重、废话连篇的消息气泡，采用专业精算纠纷仲裁书格式，支持将判语精准追溯比对合同条文原文。

本舱目前已安全上链并解析三份高发纠纷典型保单：

- **太平惠鑫保护理保险** ：长期险，蕴含等待期、续期宽限期、护理金给付。
- **平安御享常青终身寿险** ：终身险，具备20日犹豫期和比例身故责任。
- **泰康乐享健康重疾险** ：健康险，拥有180天重疾等待期及多重癌症给付。

### 📌 交互体验指引
您可以点击下方左侧的「微调模版」自动导入争议并触发大模型审计判词；
您也可以直接点击上面判定高亮的 **[等待期限制与处理]** 或 **[交费宽限期与合同中止]** 标签，右侧将瞬间开启 **“契约原文高精对照仓”**，带您比对无参水、无修饰的保单条款合同墨迹。
`,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      citations: [
        {
          policyId: 'tp-hx-2026',
          policyName: '太平惠鑫保（电子保单）',
          clauseId: 'tp-waiting-period',
          clauseTitle: '等待期限制与处理',
          section: '第二条第三款',
          matchedText: '自合同生效日起计算。本合同的等待期为90天。在等待期内，若被保险人首次发生并确诊患有本合同约定的护理状态或中度/重度护理状态，我们不承担任何保险责任，并向您无息退还已交付的全部保险费，合同随即终止。若被保险人因意外伤害事故导致护理状态，或进行合同续保的，则无需承担等待期约束。'
        },
        {
          policyId: 'tp-hx-2026',
          policyName: '太平惠鑫保（电子保单）',
          clauseId: 'tp-grace-period',
          clauseTitle: '交费宽限期与合同中止',
          section: '第三条第二款',
          matchedText: '分期支付保险费的，您在支付首期保险费后，若您在后续各期的约定交费日未交纳保费，自交费日次日零时起60天内为宽限期。宽限期内若被保险人不幸发生保险事故，我们仍承担本合同约定的保险给付责任，但有权在给付额度内直接扣除您欠交的保险费。若宽限期届满仍未足额交纳保费，本合同效力自动中止，自宽限期满次日零时起，中止期间我们不承担任何保险责任。'
        }
      ]
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chats when new response arrives
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Click handler for inline citation bracket labels
  const handleCiteClick = (clauseId: string) => {
    // Find the citation details in the current message context
    // Walk back from the latest message to find the matching clause
    for (let i = messages.length - 1; i >= 0; i--) {
      const cite = messages[i].citations?.find(c => c.clauseId === clauseId);
      if (cite) {
        setInspectingCitation(cite);
        return;
      }
    }
    // Fallback: search across all default preloaded citations
    const defaultCitations = messages[0].citations || [];
    const defaultCite = defaultCitations.find(c => c.clauseId === clauseId);
    if (defaultCite) {
      setInspectingCitation(defaultCite);
    }
  };

  // Immediate query runner
  const handleSelectQuery = (query: string) => {
    setActiveInput(query);
    triggerEvaluation(query);
  };

  // Call server-side API proxy to keep API keys completely confidential
  const triggerEvaluation = async (messageText: string) => {
    if (!messageText.trim() || isLoading) return;

    // Append user input
    const userMessage: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      content: messageText,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setActiveInput('');
    setIsLoading(true);
    setInspectingCitation(null); // Clear previous open drawer first

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: messageText,
          currentPolicyId: selectedPolicyId
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP 异常，错误码为 ${res.status}`);
      }

      const assistantMsg: Message = await res.json();
      setMessages(prev => [...prev, assistantMsg]);

      // Highlight the first citation automatically in the contract drawer!
      if (assistantMsg.citations && assistantMsg.citations.length > 0) {
        setInspectingCitation(assistantMsg.citations[0]);
      }

    } catch (err: any) {
      console.error(err);
      const errorMessage: Message = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        verdict: 'neutral',
        verdictText: '研判系统未答复。',
        content: `### ❌ 链路比对网络阻断\n大模型系统未成功做出研判响应。详情: ${err.message || '网络超时'}。\n\n**可能的原因：**\n1. 您在 AI Studio 界面侧边栏 **Settings > Secrets** 参数内未配置 \`GEMINI_API_KEY\`。\n2. 后端服务端尚未完全启动完成。您可以稍微等待 10~15 秒再次重试。`,
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
        citations: []
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearHistory = () => {
    setMessages([messages[0]]); // fallback to initial report
    setInspectingCitation(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans select-none text-slate-800">
      {/* Top Professional Header */}
      <Header />

      {/* Main Structural Space Desk */}
      <main className="max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 items-start">
        {/* LEFT COLUMN: Policies Database Vault and Scenarios templates (4/12 grid span) */}
        <section className="lg:col-span-4 flex flex-col gap-6 lg:sticky lg:top-[80px] max-h-[calc(100vh-120px)] overflow-y-auto no-scrollbar pb-4">
          <PolicyVault 
            policies={POLICIES}
            selectedPolicyId={selectedPolicyId}
            onSelectPolicy={setSelectedPolicyId}
          />
          <TemplateDeck 
            onSelectQuery={handleSelectQuery}
          />
        </section>

        {/* RIGHT COLUMN: Dialogue sandbox & active inspector panel (8/12 grid span) */}
        <section className="lg:col-span-8 flex flex-col gap-6 h-full min-h-[600px]">
          {/* Active Workmesh Grid (Split screen when citation inspector is active) */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch flex-1">
            {/* QA Stream Area (occupies full width or splits dynamically) */}
            <div className={`flex flex-col gap-5 justify-between min-h-[500px] transition-all duration-300 ${
              inspectingCitation ? 'md:col-span-7' : 'md:col-span-12'
            }`}>
              {/* Chats Log Folder */}
              <div className="flex flex-col gap-5 overflow-y-auto max-h-[640px] pr-1.5 scroll-smooth">
                {messages.map((msg, index) => {
                  const isUser = msg.sender === 'user';
                  return (
                    <div 
                      key={msg.id} 
                      className={`flex flex-col gap-1.5 transition-all ${
                        isUser ? 'items-end' : 'items-start'
                      }`}
                    >
                      {/* Sender metadata banner */}
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono uppercase px-1">
                        {isUser ? (
                          <>
                            <span>投保咨询提问 • USER</span>
                            <span>•</span>
                            <span>{msg.timestamp}</span>
                          </>
                        ) : (
                          <>
                            <span>独立合约法理裁认定案意见书 • ASSISTANT</span>
                            <span>•</span>
                            <span>{msg.timestamp}</span>
                          </>
                        )}
                      </div>

                      {/* Chat text box representation */}
                      {isUser ? (
                        <div className="p-3.5 bg-slate-800 text-white rounded-xl rounded-tr-none max-w-[85%] font-medium text-xs md:text-sm leading-relaxed tracking-wide shadow-sm border border-slate-700">
                          {msg.content}
                        </div>
                      ) : (
                        <div className="w-full animate-fade-in">
                          <VerdictDisplay
                            verdict={msg.verdict}
                            verdictText={msg.verdictText}
                            analysisText={msg.content}
                            citations={msg.citations || []}
                            onCiteClick={handleCiteClick}
                            isLoading={index === messages.length - 1 && isLoading}
                          />
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Simulated Loading Indicator */}
                {isLoading && messages[messages.length - 1].sender === 'user' && (
                  <div className="flex flex-col gap-1.5 items-start w-full">
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono tracking-wider">
                      <span>精密研判分析推理中...</span>
                    </div>
                    <div className="w-full">
                      <VerdictDisplay
                        analysisText=""
                        citations={[]}
                        onCiteClick={() => {}}
                        isLoading={true}
                      />
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Clear history & settings metrics tool belt */}
              <div className="flex items-center justify-between py-2 border-t border-slate-200/60 mt-2 text-xs text-slate-400">
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>独立审计判定通道正常运作中，研判完全提取保单字面原文</span>
                </div>
                {messages.length > 1 && (
                  <button
                    onClick={clearHistory}
                    className="flex items-center gap-1 hover:text-rose-600 transition-colors cursor-pointer"
                    title="重置会话并卸载判词记录"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>清理解析历史</span>
                  </button>
                )}
              </div>
            </div>

            {/* Contract original text inspector folio drawer */}
            {inspectingCitation && (
              <div className="md:col-span-5 h-[640px] animate-in slide-in-from-right duration-300">
                <ContractInspector
                  policyName={inspectingCitation.policyName}
                  clauseTitle={inspectingCitation.clauseTitle}
                  section={inspectingCitation.section}
                  matchedText={inspectingCitation.matchedText}
                  onClose={() => setInspectingCitation(null)}
                />
              </div>
            )}
          </div>

          {/* Active Consultation Prompt Input Box */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                🖋️ 输入您的保险契约瑕疵、交费纠纷或等待期确诊退保问题
              </span>
              <span className="text-[9px] text-slate-400 bg-slate-100 font-mono py-0.5 px-2 rounded font-semibold select-none">
                SHIFT + ENTER 换行
              </span>
            </div>

            <form 
              onSubmit={(e) => {
                e.preventDefault();
                triggerEvaluation(activeInput);
              }}
              className="flex flex-col sm:flex-row gap-3 items-stretch"
            >
              <div className="relative flex-1">
                <textarea
                  value={activeInput}
                  onChange={(e) => setActiveInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      triggerEvaluation(activeInput);
                    }
                  }}
                  placeholder="在此输入咨询，例如：“交交保费晚了两个月，此时发生事故，能不能正常获得理赔，还是要中止合同？”"
                  className="w-full min-h-[64px] max-h-[160px] p-3 text-xs md:text-sm bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 rounded-lg border border-slate-200 focus:border-blue-600/60 focus:outline-none focus:ring-1 focus:ring-blue-600/10 transition-all font-sans leading-relaxed tracking-wide placeholder-slate-400 resize-none flex-1 font-medium"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || !activeInput.trim()}
                className={`px-5 py-3 rounded-lg font-semibold text-sm flex flex-row items-center justify-center gap-2 transition-all cursor-pointer select-none active:scale-95 ${
                  isLoading || !activeInput.trim()
                    ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700 text-white border border-blue-600 shadow-sm shadow-blue-500/10'
                }`}
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                <span>递交重审</span>
              </button>
            </form>

            {/* Non-Tech larping human literal disclaimer footnotes */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[10px] text-slate-400 py-1 border-t border-dashed border-slate-200">
              <span className="flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                所有系统结论均根据内置高信度条款原文及精算规则比对做出，最终裁决以承保合同印鉴为准。
              </span>
              <span>
                保司数据安全核准注册备案号：CH-IQA-66286
              </span>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

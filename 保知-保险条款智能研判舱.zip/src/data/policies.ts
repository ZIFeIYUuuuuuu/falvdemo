/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Policy, Clause } from '../types';

export const POLICIES: Policy[] = [
  {
    id: 'tp-hx-2026',
    name: '太平惠鑫保护理保险（电子保单）',
    code: 'TP-HX-2026',
    company: '太平人寿保险有限公司',
    status: 'active',
    type: '长期护理险',
    waitingPeriod: '90天',
    gracePeriod: '60天',
    freeLookPeriod: '15天',
    clauses: [
      {
        id: 'tp-waiting-period',
        section: '第二条第三款',
        title: '等待期限制与处理',
        content: '自合同生效日起计算。本合同的等待期为90天。在等待期内，若被保险人首次发生并确诊患有本合同约定的护理状态或中度/重度护理状态，我们不承担任何保险责任，并向您无息退还已交付的全部保险费，合同随即终止。若被保险人因意外伤害事故导致护理状态，或进行合同续保的，则无需承担等待期约束。',
        scenarios: ['等待期', '首次确诊', '等待期得病', '退还保费', '生病理赔']
      },
      {
        id: 'tp-grace-period',
        section: '第三条第二款',
        title: '交费宽限期与合同中止',
        content: '分期支付保险费的，您在支付首期保险费后，若您在后续各期的约定交费日未交纳保费，自交费日次日零时起60天内为宽限期。宽限期内若被保险人不幸发生保险事故，我们仍承担本合同约定的保险给付责任，但有权在给付额度内直接扣除您欠交的保险费。若宽限期届满仍未足额交纳保费，本合同效力自动中止，自宽限期满次日零时起，中止期间我们不承担任何保险责任。',
        scenarios: ['宽限期', '延迟交费', '欠费', '交保费延迟', '合同中止', '漏交保费']
      },
      {
        id: 'tp-free-look',
        section: '第一条第四款',
        title: '犹豫期退款与解除权',
        content: '自您签收本合同电子保单并在线确认签收起，享有15日的犹豫期。在犹豫期内，你可以书面或系统申请形式撤销本合同，我们将无息退还您所交纳的全部保险费，自退保之日起本合同自始无效，我们不承担任何责任。犹豫期后退保属于正常合同解除，我们将退还解除当日保单对应的“现金价值”（见附表）。由于犹豫期后退保会产生较大经济损失，请您谨慎权衡。',
        scenarios: ['犹豫期', '退保', '15天退保', '解除合同', '现金价值', '退保费']
      },
      {
        id: 'tp-care-benefit',
        section: '第五条第一款',
        title: '长期护理保险金给付规则',
        content: '被保险人处于合同生效状态，确诊因意外伤害或于等待期后首次确诊达到长期护理状态，并持续观察评估满180天（含）以上的。我们将依约按月给付长期护理金。每月给付金额 = 基本保险金额 * 1.5%，给付节奏为按月，单次赔付期间不超过36个月，累计终身给付次数上限为3次。每次重新申请护理给付，需经过不少于1年的行业评估恢复期和观察期。',
        scenarios: ['护理金', '给付次数', '给付节奏', '护理赔付', '如何理赔', '赔多久', '每个月给多少']
      }
    ]
  },
  {
    id: 'pa-yxcq-2026',
    name: '平安御享常青终身寿险（条款）',
    code: 'PA-YXCQ-2026',
    company: '中国平安人寿保险股份有限公司',
    status: 'active',
    type: '终身寿险',
    waitingPeriod: '无等待期',
    gracePeriod: '60天',
    freeLookPeriod: '20天',
    clauses: [
      {
        id: 'pa-free-look',
        section: '第一条第二款',
        title: '20日宽裕犹豫期权益',
        content: '为了充分保护投保人利益，自您使用电子签名签收系统内保单次日起，享有20天的超长犹豫期。在犹豫期内要求撤消本合同的，我们将在扣除不超过10元系统建档与工本费后，无息全额返还已收首期保险费。款项将原路返还至缴费扣款银行账户，退费完成后合同自生命周期初始阶段起无效。',
        scenarios: ['犹豫期', '20天犹豫期', '退保', '扣10元', '电子保单签收']
      },
      {
        id: 'pa-death-benefit',
        section: '第四条第一款',
        title: '身故金核算与给付比例',
        content: '若被保险人于18周岁（不含）前身故，我们按以下两项的较大者给付身故金并终止合同：1.已交付保费总额；2.被保险人身故时本保单在系统内载明的现金价值。若被保险人18周岁（含）以上且在缴费期满前发生身故保险事故，我们按已交保费乘以下列身故年龄比例给付：18-40周岁给付160%，41-60周岁给付140%，61周岁以上给付120%。若缴费期满身故，则给付年度基本保额与身故时现金价值中最大者。',
        scenarios: ['身故金', '去世赔偿', '死亡赔偿', '赔付比例', '18岁身故', '买保险身故']
      },
      {
        id: 'pa-grace-reinstatement',
        section: '第三条第三款',
        title: '宽限期满合同中止与复效程序',
        content: '自续期应缴保险费应交日次日起算60日为缴费宽限期。宽限期满仍未交付，合同效力从第61日起自动中止。合同中止期间发生事故我们不承担任何赔付责任。在合同效力中止之起2年（含）内，您可以书面向我司申请合同复效。投保人须如实说明被保险人健康状况，提供体检报告，并补齐效力中止期间欠交的保费及资金利息。经我司风控审核同意补缴完成的次日起，合同效力正式复效，满2年未达成复效的，我司有权强制解除合同。',
        scenarios: ['停交保险', '合同中止', '复效', '缴费宽限', '逾期未交', '申请复效', '2年中止']
      }
    ]
  },
  {
    id: 'tk-lxjk-2026',
    name: '泰康乐享健康重疾险（重大疾病责任特约）',
    code: 'TK-LXJK-2026',
    company: '泰康人寿保险有限责任公司',
    status: 'active',
    type: '重大疾病险',
    waitingPeriod: '180天',
    gracePeriod: '60天',
    freeLookPeriod: '15天',
    clauses: [
      {
        id: 'tk-waiting-ci',
        section: '第二条第一款',
        title: '180天重大疾病等待期限制',
        content: '本合同生效或经审核批准复效之日零时起，至第180天（含）为疾病等待期。被保险人若在等待期内非因外在意外伤害事故，而是由于疾病病因首次发生并确诊患有本合同约定的重度疾病、中度疾病、轻度疾病的，我们不承担任何保险给付责任。我们将向投保人退还本合同累计已缴纳的全部保险费金额，同时重疾、中症、轻症责任自始终止。若由于交通意外或其他约定的突发物理意外事件导致疾病不在此限。',
        scenarios: ['等待期', '180天等待期', '重疾等待期', '生病理赔', '确诊重症']
      },
      {
        id: 'tk-cancer-multiple',
        section: '第六条第二款',
        title: '癌症（恶性肿瘤-重度）多次赔付特约',
        content: '首次重大疾病确诊为“恶性肿瘤-重度”并获赔给付首次重疾金后，生存满3年以上，再次发生恶性肿瘤（含前次恶性肿瘤的持续增加、持续浸润、细胞转移、复发或独立新发其他器官癌症），我们将再次按合同基本保险金额的100%给付保险责任金（上限为2次）。如首次确诊的重疾非恶性肿瘤，则在首次疾病确诊给付满1年后，首次确诊为恶性肿瘤，我们同样给付基本保额，本项无限期多次给付自动终止。',
        scenarios: ['多次癌症', '恶性肿瘤', '肿瘤给付', '持续浸润', '癌症复发', '3年癌症']
      }
    ]
  }
];

// Simple helper to find the most relevant clauses for a query using standard scoring matching
export function searchClauses(query: string, targetPolicyId?: string): { policy: Policy; clause: Clause; matchedWord: string; score: number }[] {
  if (!query) return [];
  const lowercaseQuery = query.toLowerCase().trim();
  const results: { policy: Policy; clause: Clause; matchedWord: string; score: number }[] = [];

  const targetPolicies = targetPolicyId 
    ? POLICIES.filter(p => p.id === targetPolicyId)
    : POLICIES;

  for (const policy of targetPolicies) {
    for (const clause of policy.clauses) {
      let score = 0;
      let matchedWord = '';

      // Match scenarios (high weight)
      for (const keyword of clause.scenarios) {
        if (lowercaseQuery.includes(keyword.toLowerCase())) {
          score += 15;
          matchedWord = keyword;
        }
      }

      // Match title (medium weight)
      if (clause.title.toLowerCase().includes(lowercaseQuery)) {
        score += 10;
        matchedWord = clause.title;
      }

      // Match content (standard weight)
      const contentWords = ['等待期', '宽限期', '犹豫期', '退保', '身故', '护理', '失效', '中止', '复效', '给付', '多次'];
      for (const w of contentWords) {
        if (lowercaseQuery.includes(w) && clause.content.includes(w)) {
          score += 5;
          if (!matchedWord) matchedWord = w;
        }
      }

      // Exact substring matches on content
      if (clause.content.toLowerCase().includes(lowercaseQuery)) {
        score += 8;
      }

      if (score > 0) {
        results.push({
          policy,
          clause,
          matchedWord: matchedWord || '核心条款',
          score
        });
      }
    }
  }

  // Sort descending by score
  return results.sort((a, b) => b.score - a.score);
}

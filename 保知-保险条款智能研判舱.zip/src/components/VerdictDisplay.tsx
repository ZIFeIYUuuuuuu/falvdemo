/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Citation } from '../types';
import { Scale, CheckCircle2, AlertTriangle, XCircle, BookOpen, FileText } from 'lucide-react';

interface VerdictDisplayProps {
  verdict?: 'valid' | 'invalid' | 'conditional' | 'neutral';
  verdictText?: string;
  analysisText: string;
  citations: Citation[];
  onCiteClick: (id: string) => void;
  isLoading?: boolean;
}

export default function VerdictDisplay({
  verdict,
  verdictText,
  analysisText,
  citations,
  onCiteClick,
  isLoading
}: VerdictDisplayProps) {

  // Helper to choose corresponding color schemas matching professional design
  const getVerdictStyles = () => {
    switch (verdict) {
      case 'valid':
        return {
          bg: 'bg-emerald-50/55 border-emerald-200 text-emerald-950',
          title: '⚖️ 研判定案：契约责任支持给付 / 保障完全有效',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-600" />,
          pill: 'bg-emerald-600 text-white'
        };
      case 'invalid':
        return {
          bg: 'bg-rose-50/55 border-rose-200 text-rose-950',
          title: '🚨 研判定案：免责范围/效力中止终止/不予给付情况',
          icon: <XCircle className="w-5 h-5 text-rose-600" />,
          pill: 'bg-rose-600 text-white'
        };
      case 'conditional':
        return {
          bg: 'bg-amber-50/55 border-amber-200 text-amber-950',
          title: '⚠️ 研判定案：需附特约限制或补齐证明条件后给付',
          icon: <AlertTriangle className="w-5 h-5 text-amber-600" />,
          pill: 'bg-amber-600 text-white'
        };
      default:
        return {
          bg: 'bg-slate-50 border-slate-200 text-slate-800',
          title: '🔍 研判定案：通用常理分析与保险细则科普意见',
          icon: <Scale className="w-5 h-5 text-slate-500" />,
          pill: 'bg-slate-600 text-white'
        };
    }
  };

  const styles = getVerdictStyles();

  // Simple line-by-line markdown and citation parser
  const renderLine = (line: string, lineIdx: number) => {
    let trimmed = line.trim();
    if (!trimmed) return <div key={lineIdx} className="h-2" />;

    // Handle Headings (e.g., ### Title)
    if (trimmed.startsWith('### ')) {
      return (
        <h3 key={lineIdx} className="text-sm font-semibold text-slate-800 mt-4 mb-2 first:mt-1 border-b border-slate-100 pb-1.5 flex items-center gap-2 font-sans">
          <div className="w-1 h-3 bg-blue-600 rounded-full" />
          {trimmed.replace('### ', '')}
        </h3>
      );
    }
    if (trimmed.startsWith('## ')) {
      return (
        <h2 key={lineIdx} className="text-slate-900 font-bold text-sm tracking-tight pt-5 pb-2 flex items-center gap-2 border-b border-slate-250">
          {trimmed.replace('## ', '')}
        </h2>
      );
    }

    // Handle Bullet points (e.g. - list item)
    let isBullet = false;
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      isBullet = true;
      trimmed = trimmed.substring(2);
    }

    // Replace citations e.g. [tp-waiting-period] with custom interactive pill buttons
    const parseCitations = (txt: string) => {
      const parts = txt.split(/(\[[a-zA-Z0-9_-]+\])/g);
      return parts.map((part, index) => {
        const match = part.match(/^\[([a-zA-Z0-9_-]+)\]$/);
        if (match) {
          const id = match[1];
          const cite = citations.find(c => c.clauseId === id);
          if (cite) {
            return (
              <button
                key={index}
                onClick={() => onCiteClick(id)}
                className="inline-flex items-center gap-1 mx-1 px-2 py-0.5 text-[10px] font-sans font-semibold text-blue-800 bg-blue-100/60 hover:bg-blue-200 rounded border border-blue-200/40 cursor-pointer select-none transition-all active:scale-95"
                title={`点击比对合同原文：${cite.clauseTitle}`}
              >
                <BookOpen className="w-3 h-3 text-blue-700" />
                {cite.clauseTitle}
              </button>
            );
          }
        }

        // Simple bold parser within parts
        const boldParts = part.split(/(\*\*[^*]+\*\*)/g);
        return boldParts.map((bPart, bIdx) => {
          if (bPart.startsWith('**') && bPart.endsWith('**')) {
            return <strong key={bIdx} className="font-semibold text-slate-900 font-sans">{bPart.slice(2, -2)}</strong>;
          }
          return bPart;
        });
      });
    };

    return (
      <div 
        key={lineIdx} 
        className={`leading-relaxed text-xs md:text-sm text-slate-600 my-1.5 font-sans tracking-wide text-justify ${
          isBullet ? 'pl-4 relative before:content-["•"] before:absolute before:left-1 before:text-slate-300' : ''
        }`}
      >
        {parseCitations(trimmed)}
      </div>
    );
  };

  const lines = analysisText.split('\n');

  return (
    <div className="flex flex-col gap-4">
      {/* 1. Verdict Statement Callout Card */}
      {verdictText && (
        <div className={`p-4 rounded-xl border-t-4 border shadow-sm transition-all ${styles.bg}`}>
          <div className="flex gap-3">
            <div className="flex-shrink-0 mt-0.5">{styles.icon}</div>
            <div className="flex flex-col gap-1 overflow-hidden">
              <span className="font-sans font-bold text-xs uppercase tracking-wider opacity-85 flex items-center gap-1.5">
                {styles.title}
              </span>
              <p className="text-xs md:text-[13px] font-semibold leading-relaxed mt-1">
                {verdictText}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 2. Citations Source Bar */}
      {citations.length > 0 && (
        <div className="px-4 py-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono mr-1">
            🔍 匹配研判法条源 ({citations.length})：
          </span>
          {citations.map((cite) => (
            <button
              key={cite.clauseId}
              onClick={() => onCiteClick(cite.clauseId)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-sans font-medium text-slate-700 hover:text-white bg-white hover:bg-blue-600 border border-slate-200 hover:border-blue-600 rounded-md cursor-pointer transition-all shrink-0 shadow-sm"
            >
              <FileText className="w-3.5 h-3.5 text-slate-400 group-hover:text-white" />
              <span>{cite.clauseTitle}</span>
            </button>
          ))}
        </div>
      )}

      {/* 3. Detailed Actuarial Reasoning Paragraphs */}
      <div className="bg-white p-6 rounded-xl border border-slate-250 relative shadow-inner overflow-hidden min-h-[150px]">
        {/* Editorial Watermark */}
        {!isLoading && (
          <div className="absolute right-4 bottom-4 pointer-events-none select-none text-[10px] text-slate-200 mt-2 font-mono uppercase tracking-widest text-right">
            BAOZHI CLAIM RAG ASSISTANT<br />AUTHENTIC EVALUATION REPORT
          </div>
        )}

        <div className="flex flex-col gap-1.5">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-4">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <div className="flex flex-col items-center gap-1">
                <p className="text-xs font-semibold text-slate-500 animate-pulse">
                  保资契约大模型推理正在就位...
                </p>
                <p className="text-[10px] text-slate-400">正在对比保单等待期、宽限时段并检索法学依据原文</p>
              </div>
            </div>
          ) : (
            lines.map((line, idx) => renderLine(line, idx))
          )}
        </div>
      </div>
    </div>
  );
}

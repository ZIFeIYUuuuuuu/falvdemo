/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, BookOpen, Shield } from 'lucide-react';

interface ContractInspectorProps {
  policyName: string;
  clauseTitle: string;
  section: string;
  matchedText: string;
  onClose: () => void;
}

export default function ContractInspector({
  policyName,
  clauseTitle,
  section,
  matchedText,
  onClose
}: ContractInspectorProps) {
  return (
    <div className="flex flex-col h-full bg-white border border-slate-200 rounded-xl shadow-md overflow-hidden">
      {/* Folio Binder Header */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1.5 bg-blue-50 text-blue-600 rounded-lg border border-blue-100">
            <BookOpen className="w-4 h-4" />
          </span>
          <div>
            <h4 className="text-xs font-bold text-slate-800 leading-none">契约原文高精对照仓</h4>
            <p className="text-[10px] text-slate-400 mt-1 font-mono uppercase tracking-wider">OFFICIAL CLAUSE VERIFICATION</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          title="关闭对照"
        >
          <X className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      {/* Folio Paper Container */}
      <div className="relative flex-1 p-5 md:p-6 overflow-y-auto bg-slate-50/50" style={{ backgroundImage: 'radial-gradient(#e2e8f0 1.5px, transparent 1.5px)', backgroundSize: '20px 20px' }}>
        {/* Paper Header / Watermark style */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-slate-400 mb-6 font-serif">
          <span className="text-[10px] font-sans">
            保知智能 RAG 鉴证库 • {policyName.replace(/（电子保单）|（条款）/, '')}
          </span>
          <span className="text-[10px] uppercase font-mono">Page REF</span>
        </div>

        {/* Paper Watermark Ornament (absolute background) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none select-none opacity-[0.025] text-blue-600 flex flex-col items-center">
          <Shield className="w-60 h-60" />
          <span className="font-serif text-2xl tracking-widest mt-4 font-bold">保知 · 契约专审</span>
        </div>

        {/* Content Details */}
        <div className="relative flex flex-col gap-4 text-slate-800">
          <div>
            <span className="inline-block px-2 py-0.5 text-[10px] font-sans font-bold bg-blue-600 text-white rounded mb-2">
              {section}
            </span>
            <h3 className="font-sans font-bold text-base text-slate-900 tracking-tight">
              {clauseTitle}
            </h3>
          </div>

          {/* Verbatim highlighted block */}
          <div className="relative p-5 bg-blue-50/40 border-l-4 border-blue-600 rounded-lg shadow-inner text-slate-700 leading-relaxed font-sans text-xs md:text-[13px] tracking-wide mt-2">
            <p className="indent-6 text-justify">
              {matchedText}
            </p>
          </div>

          {/* Verification stamp */}
          <div className="flex justify-end gap-3 items-center mt-10 text-slate-400 font-sans text-[11px] border-t border-dashed border-slate-200 pt-4">
            <span className="flex items-center gap-1 text-emerald-600 font-semibold">
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
              RAG比对校验100%一致
            </span>
            <span>•</span>
            <span className="font-mono">ID: {clauseTitle.substring(0, 8)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

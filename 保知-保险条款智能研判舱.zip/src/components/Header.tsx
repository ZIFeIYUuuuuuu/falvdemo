/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Database, HelpCircle } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200 px-6 py-3.5 shadow-sm">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Brand Logo Grid */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm shadow-blue-500/10">
            <svg 
              className="w-5 h-5 text-white" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2.5"
            >
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              <path d="m9 12 2 2 4-4" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-sans font-bold text-base tracking-tight text-slate-900">保知</span>
              <span className="px-1.5 py-0.5 text-[10px] uppercase tracking-wider font-mono bg-blue-600 text-white rounded font-semibold">
                RAG Engine v2.4
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-sans mt-0.5">INSURANCE CLAUSE CLARIFICATION WORKBENCH • 保险条款智能研判舱</p>
          </div>
        </div>

        {/* Real-time Telemetry Metrics */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Active Knowledge base status */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-600 font-medium">知识库网络：常态联通中 (3份核心承保件)</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-200 max-md:hidden">
            <Database className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-600">关联条款：<strong className="font-mono text-blue-600">99+ 权重向量段</strong></span>
          </div>

          {/* Quick Disclaimer popover */}
          <div className="flex items-center gap-1 text-slate-400 hover:text-slate-600 transition-colors cursor-help" title="审计免责说明：工作台研判意见均根据契约公式及字面计算做出，最终结论请以对应机构理算赔款为准。">
            <HelpCircle className="w-4 h-4" />
            <span className="underline decoration-dotted underline-offset-2">法律审计免责书</span>
          </div>
        </div>
      </div>
    </header>
  );
}

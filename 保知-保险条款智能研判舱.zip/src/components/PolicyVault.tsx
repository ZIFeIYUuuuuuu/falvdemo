/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, FileText, ChevronRight, Calendar, AlertCircle, Clock } from 'lucide-react';
import { Policy } from '../types';

interface PolicyVaultProps {
  policies: Policy[];
  selectedPolicyId: string | null;
  onSelectPolicy: (id: string | null) => void;
}

export default function PolicyVault({ policies, selectedPolicyId, onSelectPolicy }: PolicyVaultProps) {
  const currentPolicy = policies.find(p => p.id === selectedPolicyId);

  return (
    <div className="flex flex-col gap-5 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="p-1.5 bg-blue-50 text-blue-600 rounded-lg border border-blue-100">
            <ShieldCheck className="w-4 h-4" />
          </span>
          <h3 className="font-sans font-bold text-sm tracking-tight text-slate-800">内置保险条款数据库</h3>
        </div>
        <p className="text-xs text-slate-500 mt-1">系统已加载的核心电子条款，切换研判范围以针对特定险种进行定案。</p>
      </div>

      {/* Selector Toggle */}
      <div className="flex flex-col gap-2">
        {/* 'ALL' selector option */}
        <button
          onClick={() => onSelectPolicy(null)}
          className={`group flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
            selectedPolicyId === null
              ? 'bg-blue-50/40 border-blue-200 shadow-sm'
              : 'bg-slate-50/50 border-slate-200/80 hover:bg-slate-50 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`p-1.5 rounded-md border ${
              selectedPolicyId === null
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-slate-400 border-slate-200'
            }`}>
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-xs text-slate-800">联合智能研判 (全保单索)</div>
              <div className="text-[10px] text-slate-500 mt-0.5">跨全量候选契约智能推理匹配，提供多保单协同联动</div>
            </div>
          </div>
          {selectedPolicyId === null && (
            <div className="w-2 h-2 rounded-full bg-blue-600" />
          )}
        </button>

        {/* Dynamic Policies List */}
        {policies.map((policy) => {
          const isSelected = selectedPolicyId === policy.id;
          return (
            <button
              key={policy.id}
              onClick={() => onSelectPolicy(policy.id)}
              className={`group flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
                isSelected
                  ? 'bg-blue-50/40 border-blue-200 shadow-sm'
                  : 'bg-slate-50/50 border-slate-200/80 hover:bg-slate-50 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <div className={`p-1.5 rounded-md border flex-shrink-0 transition-colors ${
                  isSelected
                    ? 'bg-blue-100/60 text-blue-600 border-blue-200'
                    : 'bg-white text-slate-400 border-slate-200 group-hover:bg-white group-hover:text-slate-600'
                }`}>
                  <FileText className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <div className="font-semibold text-xs text-slate-800 truncate">{policy.name}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[9px] font-mono bg-slate-100 text-slate-500 py-0.5 px-1 rounded uppercase">
                      {policy.code}
                    </span>
                    <span className="text-[10px] text-slate-400">{policy.type}</span>
                  </div>
                </div>
              </div>
              <div className="flex-shrink-0 flex items-center gap-1.5">
                {isSelected ? (
                  <div className="w-2 h-2 rounded-full bg-blue-600" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-slate-400 transition-colors" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Specifications Grid Match Matrix */}
      <div className="pt-4 border-t border-slate-200">
        <h4 className="text-[10px] font-bold text-slate-400 tracking-wider uppercase font-mono mb-2.5">
          {currentPolicy ? '📑 选中条款核心履约约束指标' : '📌 契约总体时效规则对照'}
        </h4>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Waiting Period key card */}
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 hover:bg-slate-100/50 transition-colors">
            <div className="text-[10px] text-slate-400 font-medium">首次确诊等待期</div>
            <div className="font-bold text-slate-700 mt-0.5 flex items-center gap-1 font-mono text-[11px]">
              <Calendar className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              {currentPolicy ? currentPolicy.waitingPeriod : '90 ~ 180 天'}
            </div>
            <p className="text-[9px] text-slate-400 mt-1 leading-normal">非外伤事故于此期内确诊，只无息退还保费不予保障</p>
          </div>

          {/* Grace Period key card */}
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 hover:bg-slate-100/50 transition-colors">
            <div className="text-[10px] text-slate-400 font-medium">缴费逾期宽限保护期</div>
            <div className="font-bold text-slate-700 mt-0.5 flex items-center gap-1 font-mono text-[11px]">
              <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              {currentPolicy ? currentPolicy.gracePeriod : '60 天自动适用'}
            </div>
            <p className="text-[9px] text-slate-400 mt-1 leading-normal">宽限时段内发生责任事件，仍承保但会扣减所欠原保费</p>
          </div>

          {/* Free look period box */}
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/80 hover:bg-slate-100/50 transition-colors">
            <div className="text-[10px] text-slate-400 font-medium">起算无息犹豫撤销权</div>
            <div className="font-bold text-slate-700 mt-0.5 flex items-center gap-1 font-mono text-[11px]">
              <AlertCircle className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              {currentPolicy ? currentPolicy.freeLookPeriod : '15 ~ 20 天可退'}
            </div>
            <p className="text-[9px] text-slate-400 mt-1 leading-normal">自签收完成起算，此期内解除合规合同全额无息原路退还</p>
          </div>

          {/* Carrier block */}
          <div className="p-2.5 bg-slate-50/50 rounded-lg border border-dashed border-slate-200 flex flex-col justify-between">
            <div>
              <div className="text-[10px] text-slate-400">研判合规受保航道</div>
              <div className="font-semibold text-[10px] text-blue-600 mt-0.5 select-all truncate">
                {currentPolicy ? currentPolicy.company : '全行业合规总承，支持追溯'}
              </div>
            </div>
            <div className="text-[9px] text-slate-400 font-semibold mt-1 uppercase tracking-wider font-mono">
              CSRC 注册备案
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

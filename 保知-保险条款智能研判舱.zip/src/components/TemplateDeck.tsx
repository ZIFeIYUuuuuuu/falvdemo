/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HelpCircle, Clock, Calendar, ArrowRight, Sparkles } from 'lucide-react';

interface TemplateQuestion {
  label: string;
  query: string;
  desc: string;
}

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  questions: TemplateQuestion[];
}

interface TemplateDeckProps {
  onSelectQuery: (query: string) => void;
}

export default function TemplateDeck({ onSelectQuery }: TemplateDeckProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories: Category[] = [
    {
      id: 'all',
      name: '全部常见疑惑',
      icon: <Sparkles className="w-3.5 h-3.5" />,
      questions: [
        {
          label: '等待期内查出病，能赔吗？',
          query: '等待期内查出病还能赔吗？退不退款？',
          desc: '看等待期和首次确诊规则限制'
        },
        {
          label: '漏缴保费两个月，保障还在吗？',
          query: '交保费晚了两个月（大概两个多月欠费），此时如果生病出险，保险还能赔吗？',
          desc: '看合同支付宽限期与中止状态约定'
        },
        {
          label: '犹豫期内退款，有手续费吗？',
          query: '犹豫期退保怎么操作，一般手续费是怎么退？怎么退费？',
          desc: '看签收起算和手续费细则'
        },
        {
          label: '长期护理金如何给付与频次？',
          query: '保单的长期护理金是一次全额给，还是按月付？终身有什么给付次数上限吗？',
          desc: '看给付节奏和终身次数限制'
        }
      ]
    },
    {
      id: 'grace',
      name: '应交与宽限',
      icon: <Clock className="w-3.5 h-3.5" />,
      questions: [
        {
          label: '交保费晚了两个月，保障还在吗？',
          query: '交保费晚了两个月（大概两个多月欠费），此时如果生病出险，保险还能赔吗？',
          desc: '看合同支付宽限期与中止状态约定'
        }
      ]
    },
    {
      id: 'waiting',
      name: '等待与确诊',
      icon: <Calendar className="w-3.5 h-3.5" />,
      questions: [
        {
          label: '等待期内查出病，能赔吗？',
          query: '等待期内查出病还能赔吗？退不退款？',
          desc: '看等待期和首次确诊规则限制'
        }
      ]
    },
    {
      id: 'payout',
      name: '理赔与退保',
      icon: <HelpCircle className="w-3.5 h-3.5" />,
      questions: [
        {
          label: '第一天签收起算，如何犹豫撤销？',
          query: '犹豫期退保怎么操作，一般手续费是怎么退？怎么退费？',
          desc: '看犹豫期15-20天撤销及全退机制'
        },
        {
          label: '长期护理金给付次数说明？',
          query: '保单的长期护理金是一次全额给，还是按月付？终身有什么给付次数上限吗？',
          desc: '看长期护理金按月给付及评估要求'
        }
      ]
    }
  ];

  const displayedQuestions = categories.find(c => c.id === activeCategory)?.questions || [];

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-4">
      {/* Tab Header Group */}
      <div className="flex flex-col gap-1">
        <h4 className="font-sans font-bold text-xs tracking-tight text-slate-800">快速诊断模板库</h4>
        <p className="text-[11px] text-slate-400">点击下方高发契约纠纷，系统会自动检索条文并起草合同专审意见。</p>
      </div>

      {/* Categories Toggle Buttons (horizontal) */}
      <div className="flex flex-wrap gap-1 pb-1 border-b border-slate-100">
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCategory(c.id)}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              activeCategory === c.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/50'
            }`}
          >
            {c.icon}
            <span>{c.name}</span>
          </button>
        ))}
      </div>

      {/* Grid of list clickable prompt cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {displayedQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => onSelectQuery(q.query)}
            className="group p-3 rounded-lg border border-slate-200/80 bg-slate-50/30 text-left transition-all hover:bg-slate-50 hover:border-blue-600/30 hover:shadow-sm"
          >
            <div className="flex flex-col h-full justify-between gap-2">
              <div>
                <div className="text-xs font-semibold text-slate-800 leading-snug group-hover:text-blue-600 transition-colors">
                  {q.label}
                </div>
                <div className="text-[10px] text-slate-400 mt-1 font-sans">
                  {q.desc}
                </div>
              </div>
              <div className="flex items-center justify-between pt-1.5 border-t border-dashed border-slate-200/60 text-[10px] text-slate-400 group-hover:text-blue-600 font-semibold transition-all">
                <span>立即调取深度分析</span>
                <ArrowRight className="w-3 h-3 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

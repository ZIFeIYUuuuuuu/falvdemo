/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Direct import of our search utility
import { searchClauses } from "./src/data/policies.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API chat/evaluation endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, currentPolicyId } = req.body;
      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "消息内容无效。" });
      }

      // 1. Perform local RAG match to find the most related clause snippets
      const matchedClauses = searchClauses(message, currentPolicyId);

      // Assemble clause context text for the system instruction
      let contextText = "";
      const citations = matchedClauses.map((m) => {
        contextText += `\n【所属保单契约件】：${m.policy.name}\n【条款层级编号及标题】：${m.clause.section} - ${m.clause.title} (ID: ${m.clause.id})\n【契约合同条款原文】：${m.clause.content}\n【其关联校验场景】：${m.clause.scenarios.join(", ")}\n---\n`;
        return {
          policyId: m.policy.id,
          policyName: m.policy.name,
          clauseId: m.clause.id,
          clauseTitle: m.clause.title,
          section: m.clause.section,
          matchedText: m.clause.content,
        };
      });

      // 2. Initialize Google GenAI client
      const geminiKey = process.env.GEMINI_API_KEY;
      if (!geminiKey) {
        return res.status(500).json({
          error: "系统环境异常：未配置 `GEMINI_API_KEY`。请联系管理员或在 Secrets 面板关联。"
        });
      }

      const ai = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      // 3. Define the detailed system instructions
      const systemInstruction = `你是一位严谨客观、具备深厚契约法理和保险精算学术背景的专业独立保险合同审计官（中文品牌及化名：保知BaoZhi）。
你的职责是基于下面提供的[关联保单特别约定及条款原文]对比投保人的理赔、保费宽欠、退约纠纷等疑问，给出高度理智、不含AI虚无套话、一针见血的格式裁决与逻辑自洽的核算说明。

【深度研审行为准则】：
1. **字面严判**：保险关系受严格格式契约绑定。只准由于提供的[契约合同条款原文]范围内的特定数字或事实做字面演绎或排除。绝不可以过度同情或脑补未提供的承保特约。
2. **逻辑自洽与无法核决处理**：
   - 如果没有检索出任何条款片段，或者检索出的条款完全不适用于提问场景（例如用户问了一个泰康重疾险，但数据库里只有平安寿险而且没有任何癌症描述），结论评级必须裁定为 'neutral' (一般解答)。
   - 在深度研判正文 (analysisText) 内，应当极其客观、谦逊地提示：“由于我们的契约知识库目前未载入您所提及的保单条款或关联免责特约。根据通用保险理智推荐，此种情况通常遵循保监会行业范本..." 并提示寻找线下精算师核算或添加保单。
3. **精准引用格式（核心！）**：在深度研判结论正文 (analysisText) 中，只要提到某条条款内容或依据，必须在该描述的位置嵌入其对应的英文ID中括号标记，形如：'[clause-id]' （例如：'依据长期护理金的给付观察规定 [tp-care-benefit]...' 或 '根据续费宽限期的特殊减免条件 [tp-grace-period]' ）。这一部绝对必不可少，以便前台高亮追寻对应的原文对照！

以下是经过语义匹配提炼的相关保单及特定法条上下文：
${contextText || "[当前尚未检索匹配到任何直接关联的合同条款片段。]"}
`;

      // 4. Request the structural output JSON format from Gemini
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `问题内容："${message}"\n请据此出具专业保单条款智能研判 verdicts。`,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              verdict: {
                type: Type.STRING,
                description: "核算研判结论级别 必须为以下四个之一：'valid' (完全支持或保障确切有效), 'invalid' (保障中止/终止/确切不予赔付责任), 'conditional' (需核对细节后在特定条件、犹豫期或宽限期内进行附条件赔付/退保), 'neutral' (无特定纠纷场景判定或缺乏确切契约数据支撑的中立科普)"
              },
              verdictText: {
                type: Type.STRING,
                description: "用一句话客观、无套话、具有法理威严的一槌定音的研判字样（例如：“虽然交费延迟，但当前由于仍处于60日宽限期内，保障利益正常存续，若出险扣除保费后仍正常赔付。”）"
              },
              analysisText: {
                type: Type.STRING,
                description: "完整的深度法理合同逻辑推导正文。支持 Markdown 语法。要求分段落、排版具有设计感、严谨。必须包含英文字标引用标记（如 '[tp-waiting-period]' 等），风格必须客观、学术、克制、一针见血。"
              }
            },
            required: ["verdict", "verdictText", "analysisText"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Unable to obtain content from the AI Engine.");
      }

      console.log("[Gemini Response Raw]:", responseText);
      const parsedBody = JSON.parse(responseText.trim());

      return res.json({
        id: `eval-${Date.now()}`,
        sender: "assistant",
        content: parsedBody.analysisText,
        verdict: parsedBody.verdict,
        verdictText: parsedBody.verdictText,
        citations,
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      });

    } catch (error: any) {
      console.error("[Chat API Handler Error]:", error);
      return res.status(500).json({
        error: "大模型研判计算模块发生故障，请重新提问。",
        details: error.message
      });
    }
  });

  // Serve static files in production vs hook Vite middleware in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[BaoZhi Server] running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
